%/  Cinemática y dinámica de Robots
%   Proyecto final: Bin Picking
%   UDLAP                       LRT3042
%   Equipo 3      
%   15/04/2022

% Clear del caché y cierra las ventanas abiertas.
clear
close all

% Definición parámetros D-H.
    % Articulaciones:

syms q1 q2 q3 q4 q5 q6

q1 = 0;
q2 = 0;
q3 = 0;
q4 = 0;
q5 = 0;
q6 = 0;

d1 = 0.089459;
d4 = 0.10915;
d5 = 0.09465;
d6 = 0.0903;

a2= -0.425;
a3 = -0.39225;

alpha1= pi/2;
alpha4= pi/2;
alpha5= -pi/2;

    %% th,  d, a, alpha, tipo art: 0=rot 1=pris

UR5(1)= Link([q1  d1     0    alpha1    0]);  
UR5(2)= Link([q2  0      a2   0         0]);
UR5(3)= Link([q3  0      a3   0         0]);
UR5(4)= Link([q4  d4     0    alpha4    0]);  
UR5(5)= Link([q5  d5     0    alpha5    0]);
UR5(6)= Link([q6  d6     0    0         0]);

Robot= SerialLink(UR5, 'name', 'UR5');

% Plot 

%figure
%Robot.teach

%% Cinemática Inversa de manera geométrica:

% Matrices de transformación de cada articulación
syms q1i q2i q3i q4i q5i q6i

% Eval 
%{
q1i = 60;
q1i = deg2rad(q1i)
q2i = 30;
q2i = deg2rad(q2i)
q3i = -20;
q3i = deg2rad(q3i)
q4i = 10;
q4i = deg2rad(q4i)
q5i = 73;
q5i = deg2rad(q5i)
q6i = 180;
q6i = deg2rad(q6i)
%}

aAb=trotz(q1i)*transl([0 0 0.089459])*transl([0 0 0])*trotx(pi/2);
bAc=trotz(q2i)*transl([0 0 0])*transl([-0.42500 0 0])*trotx(0);
cAd=trotz(q3i)*transl([0 0 0])*transl([-0.39225 0 0])*trotx(0);
dAe=trotz(q4i)*transl([0 0 0.10915])*transl([0 0 0])*trotx(pi/2);
eAf=trotz(q5i)*transl([0 0 0.09465])*transl([0 0 0])*trotx(-pi/2);
fAg=trotz(q6i)*transl([0 0 0.0823])*transl([0 0 0])*trotx(0);



%% Theta 1:

% 0T6
aAg = aAb*bAc*cAd*dAe*eAf*fAg

% V1
v1 = [0 0 -d6 1]';

% 0P5
aPf = aAg * v1;

% Phi 1
phi1= atan2(aPf(2,1),aPf(1,1));

% Phi 2 solución 1
numerphi2 = sqrt((aPf(1,1))^2 + (aPf(2,1))^2);
phi2= acos(d4/numerphi2);

% Soluciones:

theta1_s1= phi1 + phi2 + pi/2
theta1_s2= phi1 - phi2 + pi/2

% El signo de phi 2 depende de si el hombro (s1 y s2) están a la derecha o
% a la izquierda


%% Theta 5:
syms theta5

v2 = [0 0 0 1]';

aPg = aAg * v2;

num_theta5_theta1s1 = aPg(1,1)*sin(theta1_s1) - aPg(2,1)*cos(theta1_s1)-d4;
num_theta5_theta1s2 = aPg(1,1)*sin(theta1_s2) - aPg(2,1)*cos(theta1_s2)-d4;

theta5_s1 = acos(num_theta5_theta1s1/d6)
theta5_s2 = acos(num_theta5_theta1s2/d6)
theta5_s3 = -acos(num_theta5_theta1s1/d6)
theta5_s4 = -acos(num_theta5_theta1s2/d6)

% El signo de theta5 depende de si la muñeca se encuentra hacia arriba o
% hacia abajo, tiene 4 soluciones porque depende de theta1.

%% Theta 6
aAg_inv = inv(aAg);
gAa = aAg_inv;

% Theta1_s1

% Theta1_s1 y Theta5_s1
num_val1_theta1_s1 = -gAa(2,1)*sin(theta1_s1) + gAa(2,2)*cos(theta1_s1);
val1_theta6_theta1_s1_theta5_s1= num_val1_theta1_s1 / sin(theta5_s1);

num_val2_theta1_s1 = gAa(1,1)*sin(theta1_s1) - gAa(1,2)*cos(theta1_s1);
val2_theta6_theta1_s1_theta5_s1= num_val2_theta1_s1 / sin(theta5_s1);

theta6_s1 = atan2(num_val1_theta1_s1, num_val2_theta1_s1)

% Theta1_s1 y Theta5_s2
num_val1_theta1_s1 = -gAa(2,1)*sin(theta1_s1) + gAa(2,2)*cos(theta1_s1);
val1_theta6_theta1_s1_theta5_s2= num_val1_theta1_s1 / sin(theta5_s2);

num_val2_theta1_s1 = gAa(1,1)*sin(theta1_s1) - gAa(1,2)*cos(theta1_s1);
val2_theta6_theta1_s1_theta5_s2= num_val2_theta1_s1 / sin(theta5_s2);

theta6_s2 = atan2(num_val1_theta1_s1, num_val2_theta1_s1)

% Theta1_s1 y Theta5_s3
num_val1_theta1_s1 = -gAa(2,1)*sin(theta1_s1) + gAa(2,2)*cos(theta1_s1);
val1_theta6_theta1_s1_theta5_s3= num_val1_theta1_s1 / sin(theta5_s3);

num_val2_theta1_s1 = gAa(1,1)*sin(theta1_s1) - gAa(1,2)*cos(theta1_s1);
val2_theta6_theta1_s1_theta5_s3= num_val2_theta1_s1 / sin(theta5_s3);

theta6_s3 = atan2(num_val1_theta1_s1, num_val2_theta1_s1)

% Theta1_s1 y Theta5_s4
num_val1_theta1_s1 = -gAa(2,1)*sin(theta1_s1) + gAa(2,2)*cos(theta1_s1);
val1_theta6_theta1_s1_theta5_s4= num_val1_theta1_s1 / sin(theta5_s4);

num_val2_theta1_s1 = gAa(1,1)*sin(theta1_s1) - gAa(1,2)*cos(theta1_s1);
val2_theta6_theta1_s1_theta5_s4= num_val2_theta1_s1 / sin(theta5_s4);

theta6_s4 = atan2(num_val1_theta1_s1, num_val2_theta1_s1)

% Theta1_s2

% Theta1_s2 y Theta5_s1
num_val1_theta1_s2 = -gAa(2,1)*sin(theta1_s2) + gAa(2,2)*cos(theta1_s2);
val1_theta6_theta1_s2_theta5_s1= num_val1_theta1_s2 / sin(theta5_s2);

num_val2_theta1_s2 = gAa(1,1)*sin(theta1_s2) - gAa(1,2)*cos(theta1_s2);
val2_theta6_theta1_s2_theta5_s1= num_val2_theta1_s2 / sin(theta5_s2);

theta6_s5 = atan2(num_val1_theta1_s2, num_val2_theta1_s2)

% Theta1_s2 y Theta5_s2
num_val1_theta1_s2 = -gAa(2,1)*sin(theta1_s2) + gAa(2,2)*cos(theta1_s2);
val1_theta6_theta1_s2_theta5_s2= num_val1_theta1_s2 / sin(theta5_s2);

num_val2_theta1_s2 = gAa(1,1)*sin(theta1_s2) - gAa(1,2)*cos(theta1_s2);
val2_theta6_theta1_s2_theta5_s2= num_val2_theta1_s2 / sin(theta5_s2);

theta6_s6 = atan2(num_val1_theta1_s2, num_val2_theta1_s2)

% Theta1_s2 y Theta5_s3
num_val1_theta1_s2 = -gAa(2,1)*sin(theta1_s2) + gAa(2,2)*cos(theta1_s2);
val1_theta6_theta1_s2_theta5_s3= num_val1_theta1_s2 / sin(theta5_s3);

num_val2_theta1_s2 = gAa(1,1)*sin(theta1_s2) - gAa(1,2)*cos(theta1_s2);
val2_theta6_theta1_s2_theta5_s3= num_val2_theta1_s2 / sin(theta5_s3);

theta6_s7 = atan2(num_val1_theta1_s2, num_val2_theta1_s2)

% Theta1_s1 y Theta5_s4
num_val1_theta1_s2 = -gAa(2,1)*sin(theta1_s2) + gAa(2,2)*cos(theta1_s2);
val1_theta6_theta1_s2_theta5_s4= num_val1_theta1_s2 / sin(theta5_s4);

num_val2_theta1_s2 = gAa(1,1)*sin(theta1_s2) - gAa(1,2)*cos(theta1_s2);
val2_theta6_theta1_s2_theta5_s4= num_val2_theta1_s2 / sin(theta5_s4);

theta6_s8 = atan2(num_val1_theta1_s2, num_val2_theta1_s2)

% Las ocho soluciones de theta 6 dependen de theta1 (que tiene dos
% soluciones) y de theta5 (que tiene cuatro porque depende de theta1 que
% tiene dos).

%% Theta 3

bAe = bAc*cAd*dAe;

bPe = bAe * v2;

bPe_z = bPe(3,1);
bPe_x = bPe(1,1);

bPe_xz = sqrt((-bPe_z)^2 + (-bPe_x)^2);

num_theta3 = abs(bPe_xz)^2 - a2^2 - a3^2;
den_theta3 = 2 * a2 * a3;

theta3_s1 = acos(num_theta3/den_theta3)
theta3_s2 = -theta3_s1

% Para saber si es positivo o negativo, corresponde a si el codo está
% arriba o abajo.


%% Theta 2

theta2_s1 = atan2(-bPe_z,-bPe_x) - asin((-a3 * sin(theta3_s1))/ abs(bPe_xz))
theta2_s2 = atan2(-bPe_z,-bPe_x) - asin((-a3 * sin(theta3_s2))/ abs(bPe_xz))

% Las dos soluciones de theta 2 dependen activamente de las soluciones de
% theta 3.

%% Theta4

dAe_xy = dAe(2,1);
dAe_xx = dAe(1,1);

theta4 = atan2(dAe_xy,dAe_xx)


% Listado de soluciones:

% Theta 6

Sol1 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s1]
Sol2 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s2]
Sol3 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s3]
Sol4 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s4]
Sol5 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s5]
Sol6 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s6]
Sol7 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s7]
Sol8 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s8]

% Theta 5
Sol9 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s1]
Sol10 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s2]
Sol11 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s3]
Sol12 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s4]
Sol13 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s5]
Sol14 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s6]
Sol15 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s7]
Sol16 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s8]

Sol17 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s1]
Sol18 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s2]
Sol19 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s3]
Sol20 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s4]
Sol21 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s5]
Sol22 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s6]
Sol23 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s7]
Sol24 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s8]

Sol25 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s1]
Sol26 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s2]
Sol27 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s3]
Sol28 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s4]
Sol29 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s5]
Sol30 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s6]
Sol31 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s7]
Sol32 = [theta1_s1 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s8]

% Theta 3
Sol33 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s1]
Sol34 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s2]
Sol35 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s3]
Sol36 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s4]
Sol37 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s5]
Sol38 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s6]
Sol39 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s7]
Sol40 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s8]

Sol41 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s1]
Sol42 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s2]
Sol43 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s3]
Sol44 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s4]
Sol45 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s5]
Sol46 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s6]
Sol47 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s7]
Sol48 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s8]

Sol49 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s1]
Sol50 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s2]
Sol51 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s3]
Sol52 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s4]
Sol53 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s5]
Sol54 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s6]
Sol55 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s7]
Sol56 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s8]

Sol57 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s1]
Sol58 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s2]
Sol59 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s3]
Sol60 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s4]
Sol61 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s5]
Sol62 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s6]
Sol63 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s7]
Sol64 = [theta1_s1 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s8]

% Theta 2

Sol65 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s1]
Sol66 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s2]
Sol67 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s3]
Sol68 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s4]
Sol69 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s5]
Sol70 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s6]
Sol71 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s7]
Sol72 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s8]

Sol73 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s1]
Sol74 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s2]
Sol75 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s3]
Sol76 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s4]
Sol77 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s5]
Sol78 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s6]
Sol79 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s7]
Sol80 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s8]

Sol81 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s1]
Sol82 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s2]
Sol83 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s3]
Sol84 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s4]
Sol85 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s5]
Sol86 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s6]
Sol87 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s7]
Sol88 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s8]

Sol89 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s1]
Sol90 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s2]
Sol91 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s3]
Sol92 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s4]
Sol93 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s5]
Sol94 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s6]
Sol95 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s7]
Sol96 = [theta1_s1 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s8]

Sol97 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s1]
Sol98 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s2]
Sol99 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s3]
Sol100 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s4]
Sol101 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s5]
Sol102 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s6]
Sol103= [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s7]
Sol104 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s8]

Sol106 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s1]
Sol107 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s2]
Sol108 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s3]
Sol109 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s4]
Sol110 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s5]
Sol111 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s6]
Sol112 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s7]
Sol113 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s8]

Sol114 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s1]
Sol115 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s2]
Sol116 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s3]
Sol117 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s4]
Sol118 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s5]
Sol119 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s6]
Sol120 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s7]
Sol121 = [theta1_s1 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s8]

% Theta 1

Sol122 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s1]
Sol123 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s2]
Sol124 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s3]
Sol125 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s4]
Sol126 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s5]
Sol127 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s6]
Sol128 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s7]
Sol129 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s1 theta6_s8]

Sol130 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s1]
Sol131 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s2]
Sol132 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s3]
Sol133 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s4]
Sol134 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s5]
Sol135 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s6]
Sol136 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s7]
Sol137 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s2 theta6_s8]

Sol138 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s1]
Sol139 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s2]
Sol140 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s3]
Sol141 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s4]
Sol142 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s5]
Sol143 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s6]
Sol144 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s7]
Sol145 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s3 theta6_s8]

Sol146 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s1]
Sol147 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s2]
Sol148 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s3]
Sol149 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s4]
Sol150 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s5]
Sol151 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s6]
Sol152 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s7]
Sol153 = [theta1_s2 theta2_s1 theta3_s1 theta4 theta5_s4 theta6_s8]

Sol154 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s1]
Sol155 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s2]
Sol156 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s3]
Sol157 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s4]
Sol158 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s5]
Sol159 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s6]
Sol160 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s7]
Sol161 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s1 theta6_s8]

Sol162 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s1]
Sol163 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s2]
Sol164 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s3]
Sol165 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s4]
Sol166 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s5]
Sol167 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s6]
Sol168 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s7]
Sol169 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s2 theta6_s8]

Sol170 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s1]
Sol171 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s2]
Sol172 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s3]
Sol173 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s4]
Sol174 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s5]
Sol175 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s6]
Sol176 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s7]
Sol177 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s3 theta6_s8]

Sol178 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s1]
Sol179 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s2]
Sol180 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s3]
Sol181 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s4]
Sol182 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s5]
Sol183 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s6]
Sol184 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s7]
Sol185 = [theta1_s2 theta2_s1 theta3_s2 theta4 theta5_s4 theta6_s8]

Sol186 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s1]
Sol187 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s2]
Sol188 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s3]
Sol189 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s4]
Sol190 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s5]
Sol191 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s6]
Sol192 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s7]
Sol193 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s1 theta6_s8]

Sol194 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s1]
Sol195 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s2]
Sol196 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s3]
Sol197 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s4]
So198 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s5]
Sol199 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s6]
Sol200 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s7]
Sol201 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s2 theta6_s8]
Sol202 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s1]
Sol203 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s2]
Sol204 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s3]
Sol205 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s4]
Sol206 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s5]
Sol207 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s6]
Sol208 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s7]
Sol209 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s3 theta6_s8]

Sol210 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s1]
Sol211 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s2]
Sol212 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s3]
Sol213 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s4]
Sol214 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s5]
Sol215 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s6]
Sol216 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s7]
Sol217 = [theta1_s2 theta2_s2 theta3_s1 theta4 theta5_s4 theta6_s8]

Sol218 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s1]
Sol219 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s2]
Sol220 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s3]
Sol221 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s4]
Sol222 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s5]
Sol223 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s6]
Sol224 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s7]
Sol225 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s1 theta6_s8]

Sol226 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s1]
Sol227 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s2]
Sol228 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s3]
Sol229 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s4]
Sol230 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s5]
Sol231 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s6]
Sol232 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s7]
Sol233 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s2 theta6_s8]

Sol234 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s1]
Sol235 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s2]
Sol236 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s3]
Sol237 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s4]
Sol238 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s5]
Sol239 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s6]
Sol240 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s7]
Sol241 = [theta1_s2 theta2_s2 theta3_s2 theta4 theta5_s3 theta6_s8]







