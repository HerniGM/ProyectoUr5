%/  Cinemática y dinámica de Robots
%   Proyecto final: Bin Picking
%   UDLAP                       LRT3042
%   Equipo 3      
%   03/04/2022

% Clear del caché y cierra las ventanas abiertas.
clear
close all

% Definición parámetros D-H.
    % Articulaciones:

syms q1 q2 q3 q4 q5 q6

q1 = 0;
q2 = 0;
q3 = 0;
q4 = 0;
q5 = 0;
q6 = 0;

d1 = 0.089459;
d4 = 0.10915;
d5 = 0.09465;
d6 = 0.0903;

a2= -0.425;
a3 = -0.39225;

alpha1= pi/2;
alpha4= pi/2;
alpha5= -pi/2;

    %% th,  d, a, alpha, tipo art: 0=rot 1=pris

UR5(1)= Link([q1  d1     0    alpha1    0]);  
UR5(2)= Link([q2  0      a2   0         0]);
UR5(3)= Link([q3  0      a3   0         0]);
UR5(4)= Link([q4  d4     0    alpha4    0]);  
UR5(5)= Link([q5  d5     0    alpha5    0]);
UR5(6)= Link([q6  d6     0    0         0]);

Robot= SerialLink(UR5, 'name', 'UR5');
Robot.teach


%% Cinemática Inversa (Analítica)
%{

% Configuración de las q's de cada articulación

syms config_qart1 config_qart2 config_qart3 config_qart4 
syms config_qart5 config_qart6

config_qart1 = pi;
config_qart2 = pi;
config_qart3 = pi;
config_qart4 = pi;
config_qart5 = pi;
config_qart6 = pi;

% Se obtiene la SE3 de esa configuración
T = Robot.fkine([config_qart1 config_qart2 config_qart3 config_qart4 config_qart5 config_qart6])

% Se obtiene la matriz posición en x, y y z del efector final.
pos=T.t

% Se obtiene la matriz orientación en roll, pitch y yaw del efector
% final a partir de theta y r.
ori=tr2rpy(T,'xyz')

% Matriz noap (matriz ortonormal, n, o y a representan orientación y
% p representa la posición del efector final del robot).
noap = T

% Matrices de transformación de cada articulación
syms q1i q2i q3i q4i q5i q6i
aAb=trotz(q1i)*transl([0 0 0.089459])*transl([0 0 0])*trotx(pi/2);
bAc=trotz(q2i)*transl([0 0 0])*transl([-0.42500 0 0])*trotx(0);
cAd=trotz(q3i)*transl([0 0 0])*transl([-0.39225 0 0])*trotx(0);
dAe=trotz(q4i)*transl([0 0 0.10915])*transl([0 0 0])*trotx(pi/2);
eAf=trotz(q5i)*transl([0 0 0.09465])*transl([0 0 0])*trotx(-pi/2);
fAg=trotz(q6i)*transl([0 0 0.0823])*transl([0 0 0])*trotx(0);

% Matriz noap

syms nx ny nz ox oy oz ax ay az px py pz
noap=[nx ox ax px;ny oy ay py;nz oz az pz;0 0 0 1];

%% Pasos

% Paso 1

aAb*bAc*cAd*dAe*eAf*fAg==noap
inv(aAb)*noap==bAc*cAd*dAe*eAf*fAg;
p1izq=inv(aAb)*noap;
p1izq=simplify(p1izq);
p1der=bAc*cAd*dAe*eAf*fAg;
p1der=simplify(p1der)
ec1=p1izq(3,4)==p1der(3,4)
%}














