%/  Cinemática y dinámica de Robots
%   Proyecto final: Bin Picking
%   UDLAP                       LRT3042
%   Equipo 3      
%   13/04/2022

% Clear del caché y cierra las ventanas abiertas.
clear
close all

% Definición parámetros D-H.
    % Articulaciones:

syms q1 q2 q3 q4 q5 q6

q1 = 0;
q2 = 0;
q3 = 0;
q4 = 0;
q5 = 0;
q6 = 0;

d1 = 0.089459;
d4 = 0.10915;
d5 = 0.09465;
d6 = 0.0903;

a2= -0.425;
a3 = -0.39225;

alpha1= pi/2;
alpha4= pi/2;
alpha5= -pi/2;

    %% th,  d, a, alpha, tipo art: 0=rot 1=pris

UR5(1)= Link([q1  d1     0    alpha1    0]);  
UR5(2)= Link([q2  0      a2   0         0]);
UR5(3)= Link([q3  0      a3   0         0]);
UR5(4)= Link([q4  d4     0    alpha4    0]);  
UR5(5)= Link([q5  d5     0    alpha5    0]);
UR5(6)= Link([q6  d6     0    0         0]);

Robot= SerialLink(UR5, 'name', 'UR5');

%% Cinemática inversa (toolbox)

% Se establecen valores simbólicos para las articulaciones
syms q1i q2i q3i q4i q5i q6i

% Se determina qz como el vector que dará valores a las articulaciones
qz=[q1i q2i q3i q4i q5i q6i];

% Se utiliza el q_cheat para acercar las articulaciones a la solución, esto
% permite que se presenten menos errores a la hora de utilizar ikine.
q_cheat=[0 0 0 100 100 100];
q_cheat=deg2rad(q_cheat)

% Se asignan los valores buscados.
q1i = 60;
q2i = 30;
q3i = -20;
q4i = 10;
q5i = 73;
q6i = 180;

qz= eval(qz)

qz = deg2rad(qz)
cd=Robot.fkine(qz)

ci=Robot.ikine(cd,'q0',q_cheat)

% Plot
figure
Robot.plot(ci)